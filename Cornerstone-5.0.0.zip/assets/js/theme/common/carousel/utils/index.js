export { default as heroCarouselSetup } from './heroCarouselSetup';
export { default as arrowAriaLabling } from './arrowAriaLabling';
export { default as dotsSetup } from './dotsSetup';
export { default as getRealSlidesQuantityAndCurrentSlide } from './getRealSlidesQuantityAndCurrentSlide';
export { default as setTabindexes } from './setTabindexes';
